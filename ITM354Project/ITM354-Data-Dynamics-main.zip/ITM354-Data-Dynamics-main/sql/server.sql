/* Initialize and Create Database */

CREATE DATABASE Ooohmami;
USE Ooohmami;


/* Create Tables */

CREATE TABLE _____
(
    
)
