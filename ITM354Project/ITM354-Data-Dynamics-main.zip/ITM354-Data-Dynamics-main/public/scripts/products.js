const products = [
    {
      name: "Teriyaki Jerky",
      description: "Teriyaki flavored jerky.....",
      price: 15.99,
      image: "https://i.imgur.com/jhVDsdy.jpeg"
    }
];